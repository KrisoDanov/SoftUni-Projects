﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace EntityFrameworkDemo
{
    public class StartUp
    {
        private static object stringBuilder;

        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();

            string result = GetEmployeesFullInformation(context);
            Console.WriteLine(result);
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employee = context.
                Employees
                .Where(e => e.Salary > 50000)
                .OrderBy(e => e.FirstName).ToList();

            foreach (var e in employee)
            {
                sb
                     .AppendLine($"{e.FirstName} - {e.Salary:f2}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employee = context
                .Employees
                .OrderBy(x => x.EmployeeId);
            foreach (var item in employee)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} {item.MiddleName} {item.Salary}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
