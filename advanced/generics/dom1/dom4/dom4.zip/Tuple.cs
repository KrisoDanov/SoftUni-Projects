﻿using System;
using System.Collections.Generic;
using System.Text;

namespace dom4
{
    class Tuple<Titem, Titem2>
    {
        public Tuple(Titem value1, Titem2 value2)
        {
            this.Value1 = value1;
            this.Value2 = value2;
        }
        public Titem Value1 { get; set; }
        public Titem2 Value2 { get; set; }

        public override string ToString()
        {
            return $"{Value1} -> {Value2}";
        }
    }
}
