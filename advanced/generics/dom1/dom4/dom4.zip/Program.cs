﻿using System;

namespace dom4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input1 = Console.ReadLine().Split();
            string name = input1[0] + " " + input1[1];
            string city = input1[2];

            Tuple<string, string> town = new Tuple<string, string>(name, city);
            Console.WriteLine(town);

            string[] input2 = Console.ReadLine().Split();
            string namee = input1[0];
            int litres = int.Parse(input2[1]);
            Tuple<string, int> output = new Tuple<string, int>(namee, litres);
            Console.WriteLine(output);

            string[] input3 = Console.ReadLine().Split();
            int integer = int.Parse(input3[0]);
            double number = double.Parse(input3[1]);
            Tuple<int, double> outputt = new Tuple<int, double>(integer, number);
            Console.WriteLine(outputt);

        }
    }
}
